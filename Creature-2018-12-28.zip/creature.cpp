#include<bits/stdc++.h>
#include<windows.h>
#define FullWidth GetSystemMetrics(SM_CXSCREEN)
#define FullHeight GetSystemMetrics(SM_CYSCREEN)
#define Width 1000
#define Height 600
#define CmdMenu 28
using namespace std;
HWND hwnd,cmd;
HDC WinMap,dWinMap,wbk,bbk;
HBITMAP dbm,ddbm; 
HFONT hFont;
HBRUSH black,red,green,blue,white;
bool cell[Width][Height],cell2[Width][Height],stop,up,dn,lf,rt;
int height,width,Each=1;
POINT pos1,pos2,LU;
void Init(HWND hwnd);
void Paint();
void Run();
void ydj(int x,int y);
void block(int x,int y);
int Get(int x,int y);
LRESULT CALLBACK WndProc(HWND hWnd,UINT Message,WPARAM wParam,LPARAM lParam){
	if(hWnd==hwnd){
		switch(Message){
			case WM_LBUTTONDOWN:{
				int x=LOWORD(lParam)+LU.x;
				int y=HIWORD(lParam)+LU.y;
				if(x>=Width)break;
				ydj(x/Each,y/Each);
				break;
			}
			case WM_RBUTTONDOWN:{
				int x=LOWORD(lParam)+LU.x;
				int y=HIWORD(lParam)+LU.y;
				block(x/Each,y/Each);
				break;
			}
			case WM_MOUSEWHEEL:{
				short dis=HIWORD(wParam);
				Each+=dis/120;
				Each=min(500,Each);
				Each=max(1,Each);
				break;
			} 
			case WM_KEYDOWN:{
				switch(wParam){
					case VK_SPACE:stop^=1;break;
					case 'W':{up=true;break;}
					case 'S':dn=true;break;
					case 'A':lf=true;break;
					case 'D':rt=true;break;
					case 'Z':exit(0);
					break;
				}
				break;
			}
			case WM_KEYUP:{
				switch(wParam){
					case 'W':up=false;break;
					case 'S':dn=false;break;
					case 'A':lf=false;break;
					case 'D':rt=false;break;
					break;
				}
				default:break;
			}
		}
	}
	if(Message==WM_DESTROY){return PostQuitMessage(0),0;}
	return DefWindowProc(hWnd, Message, wParam, lParam);
}
signed WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow){
	WNDCLASSEX wc;MSG msg;
	HINSTANCE HIN_CMD;
	memset(&wc,0,sizeof(wc));
	wc.cbSize=sizeof(WNDCLASSEX);
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hbrBackground=(HBRUSH)(COLOR_WINDOW-5);
	wc.lpfnWndProc=WndProc;
	wc.hInstance=hInstance;
	wc.lpszClassName="WindowClass";
	wc.hIcon=(HICON)LoadImage(GetModuleHandle(0),"pictures\\Creature.ico",IMAGE_ICON,128,128,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	wc.hIconSm=(HICON)LoadImage(GetModuleHandle(0),"pictures\\Creatuer.ico",IMAGE_ICON,128,128,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if(!RegisterClassEx(&wc))exit(0);
	hwnd=CreateWindowEx(
		WS_EX_CLIENTEDGE,
		"WindowClass","Creature",
		WS_VISIBLE|WS_OVERLAPPEDWINDOW,
		(FullWidth-Width/*-150*/)/2,(FullHeight-Height)/2,
		Width/*+150*/,Height,
		NULL,
		NULL,
		hInstance,
		NULL
		);
	/*
	cmd=CreateWindow(
		"WindowClass","",
        WS_CHILD|WS_VISIBLE|WS_BORDER|ES_LEFT,
		Width,0,150,Height,
		hwnd,
		(HMENU)CmdMenu,
		HIN_CMD,
		NULL
		);
	*/
	if(hwnd==NULL)return MessageBox(NULL,"Window Creation Failed!","Error!",MB_ICONEXCLAMATION|MB_OK),0;
	Init(hwnd);
	while(msg.message!=WM_QUIT){
		if(PeekMessage(&msg,0,0,0,PM_REMOVE)){TranslateMessage(&msg),DispatchMessage(&msg);}
		else{
			Run();
			Paint();
	    }
    }
}
void Init(HWND hwnd)
{
	srand(time(0));
	hFont==CreateFont(
            -50, -25, 0, 0, 400,
            FALSE,FALSE,FALSE,
            DEFAULT_CHARSET,
            OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS,
            DEFAULT_QUALITY,
            FF_DONTCARE,
            TEXT("΢���ź�")
            );
    black=CreateSolidBrush(RGB(0,0,0));
	red=CreateSolidBrush(RGB(255,0,0));
	green=CreateSolidBrush(RGB(0,255,0));
	blue=CreateSolidBrush(RGB(0,0,255));
	white=CreateSolidBrush(RGB(255,255,255));
	WinMap=GetDC(hwnd);
	dWinMap=CreateCompatibleDC(WinMap);
	dbm=CreateCompatibleBitmap(WinMap,Width,Height);
	SelectObject(dWinMap,dbm);
	SelectObject(dWinMap,black);
	width=Width/Each;
	height=Height/Each;
	LU.x=LU.y=0;
	Each=10; 
	return;
	for(int x=0;x<width;x+=4)
	for(int y=0;y<height;y+=4)
		block(x,y);
}
void Paint(){
	Rectangle(dWinMap,-1,-1,Width+1,Height+1);
	for(int x=LU.x/Each;x<(LU.x+Width)/Each;x++)
	for(int y=LU.y/Each;y<(LU.y+Height)/Each;y++){
		for(int i=x*Each-LU.x;i<x*Each+Each-LU.x;i++)
		for(int j=y*Each-LU.y;j<y*Each+Each-LU.y;j++)
		SetPixel(dWinMap,i,j,cell[x][y]?RGB(255,255,255):RGB(0,0,0));
	}
	BitBlt(WinMap,0,0,Width,Height,dWinMap,0,0,SRCCOPY);
}
void Run(){
	if(up)LU.y-=Height/10;
	if(dn)LU.y+=Height/10;
	if(lf)LU.x-=Width/10;
	if(rt)LU.x+=Width/10;
	LU.y=max(LU.y,(long)0);
	LU.y=min(LU.y,(long)max(height*Each-Height,0));
	LU.x=max(LU.x,(long)0);
	LU.x=min(LU.x,(long)max(width*Each-Width,0));
	if(stop)return; 
	for(int x=0;x<width;x++)
	for(int y=0;y<height;y++){
		int num=Get(x,y);
		cell2[x][y]=false;
		if(num==2)cell2[x][y]=cell[x][y];
		if(num==3)cell2[x][y]=true;
	}
	for(int x=0;x<width;x++)
	for(int y=0;y<height;y++)
		cell[x][y]=cell2[x][y];
}
int Get(int x,int y){
	int re=0,a,b,c,d;
	a=x-1<0?width-1:x-1;
	b=x+1>=width?0:x+1;
	c=y-1<0?height-1:y-1;
	d=y+1>=height?0:y+1;
	re+=cell[a][c]+cell[a][y]+cell[a][d];
	re+=cell[x][c]+cell[x][d];
	re+=cell[b][c]+cell[b][y]+cell[b][d];
	return re;
}
void ydj(int x,int y){
	int a,b,c,d;
	a=x-1<0?width-1:x-1;
	b=x+1>=width?0:x+1;
	c=y-1<0?height-1:y-1;
	d=y+1>=height?0:y+1;
	cell[a][y]=cell[x][y]=cell[x][c]=cell[b][c]=cell[b][d]=true;
}
void block(int x,int y){
	int a,b,c,d;
	a=x-1<0?width-1:x-1;
	b=x+1>=width?0:x+1;
	c=y-1<0?height-1:y-1;
	d=y+1>=height?0:y+1;
	cell[x][y]=cell[x][d]=cell[b][y]=cell[b][d]=true;
}
